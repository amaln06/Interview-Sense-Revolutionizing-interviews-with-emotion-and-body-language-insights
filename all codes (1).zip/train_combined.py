import os
import json
from typing import List, Tuple
import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import ElasticNet
from sklearn.metrics import mean_absolute_error
from sklearn.model_selection import GroupKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

RANDOM_STATE = 42
N_SPLITS = 5

# -------------------------------
# Load dataset
# -------------------------------
def load_combined_dataset(csv_path: str = "combined_aligned_dataset.csv") -> Tuple[pd.DataFrame, pd.DataFrame, pd.Series, List[str], List[str]]:
    print(f"Loading dataset from {csv_path}...")
    df = pd.read_csv(csv_path, low_memory=False)
    print(f"Dataset shape: {df.shape}")

    participants = df['participant_id'].unique().tolist()
    label_cols = [col for col in df.columns if col.startswith('LABEL_')]
    feature_cols = [col for col in df.columns if col not in label_cols + ['participant_id']]

    X = df[feature_cols].apply(pd.to_numeric, errors='coerce').fillna(0)
    y = df[label_cols]
    groups = df['participant_id']

    return X, y, groups, participants, feature_cols, label_cols

# -------------------------------
# Aggregate frame-level to interview-level
# -------------------------------
def aggregate_to_interview_level(X: pd.DataFrame, y: pd.DataFrame, groups: pd.Series) -> Tuple[pd.DataFrame, pd.DataFrame, List[str]]:
    print("Aggregating frame-level data to interview-level...")
    X_agg = X.groupby(groups).agg(['mean', 'std']).fillna(0)
    X_agg.columns = [f"{col[0]}_{col[1]}" for col in X_agg.columns]
    y_agg = y.groupby(groups).first()
    participants = groups.unique().tolist()
    print(f"Aggregated shape: {X_agg.shape}, Participants: {len(participants)}")
    return X_agg, y_agg, participants

# -------------------------------
# Train regression models
# -------------------------------
def train_and_evaluate(X: pd.DataFrame, y: pd.DataFrame, participants: List[str], feature_cols: List[str], label_cols: List[str], out_dir: str = "models") -> None:
    os.makedirs(out_dir, exist_ok=True)
    
    # -------------------------------
    # Metadata
    # -------------------------------
    metadata = {
        "features": list(X.columns),
        "labels": label_cols,
        "participants": participants,
        "n_participants": len(participants),
        "n_features": len(X.columns),
        "n_labels": len(label_cols)
    }
    with open(os.path.join(out_dir, "metadata.json"), "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)
    
    # -------------------------------
    # Participant-level CV
    # -------------------------------
    gkf = GroupKFold(n_splits=N_SPLITS)
    scaler = StandardScaler()
    reg_models = {}
    reg_metrics = {}
    all_predictions = []

    for label in label_cols:
        print(f"\nTraining regressor for {label}...")
        y_cont = pd.to_numeric(y[label], errors='coerce')
        pipe = Pipeline([
            ("scaler", scaler),
            ("reg", ElasticNet(alpha=0.1, l1_ratio=0.5, random_state=RANDOM_STATE, max_iter=2000))
        ])

        maes = []
        fold_preds = []

        for fold, (train_idx, test_idx) in enumerate(gkf.split(X, y_cont, participants)):
            X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
            y_train, y_test = y_cont.iloc[train_idx], y_cont.iloc[test_idx]
            
            pipe.fit(X_train, y_train)
            pred = pipe.predict(X_test)
            mae = mean_absolute_error(y_test, pred)
            maes.append(mae)

            fold_df = pd.DataFrame({
                "participant_id": np.array(participants)[test_idx],
                "label": label,
                "y_true": y_test.values,
                "y_pred": pred
            })
            fold_preds.append(fold_df)

        # Train on full data for saving model
        reg_models[label] = pipe.fit(X, y_cont)
        reg_metrics[label] = {
            "mae_mean": float(np.mean(maes)),
            "mae_std": float(np.std(maes))
        }

        all_predictions.append(pd.concat(fold_preds))

        print(f"  MAE: {reg_metrics[label]['mae_mean']:.3f} ± {reg_metrics[label]['mae_std']:.3f}")

    # -------------------------------
    # Save models
    # -------------------------------
    joblib.dump({"models": reg_models, "metrics": reg_metrics}, os.path.join(out_dir, "reg_models.joblib"))

    # -------------------------------
    # Save CV report
    # -------------------------------
    report = {
        "regression": reg_metrics,
        "summary": {"avg_mae": float(np.mean([m["mae_mean"] for m in reg_metrics.values()]))}
    }
    with open(os.path.join(out_dir, "cv_report.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)

    # -------------------------------
    # Save individual CV predictions
    # -------------------------------
    all_preds_df = pd.concat(all_predictions)
    all_preds_df.to_csv(os.path.join(out_dir, "cv_predictions.csv"), index=False)

    print(f"\n=== Training Complete ===")
    print(f"Average MAE: {report['summary']['avg_mae']:.3f}")
    print(f"\nSaved to {out_dir}/: metadata.json, reg_models.joblib, cv_report.json, cv_predictions.csv")

# -------------------------------
# Predict on new data
# -------------------------------
def predict_new_data(csv_path: str, model_dir: str = "models", output_csv: str = "predictions_test.csv"):
    X_new, y_dummy, groups_new, participants_new, feature_cols, label_cols = load_combined_dataset(csv_path)
    X_agg, y_agg, participants_agg = aggregate_to_interview_level(X_new, y_dummy, groups_new)

    model_data = joblib.load(os.path.join(model_dir, "reg_models.joblib"))
    reg_models = model_data["models"]

    preds = []
    for label, model in reg_models.items():
        pred_values = model.predict(X_agg)
        preds.append(pd.DataFrame({
            "participant_id": participants_agg,
            "label": label,
            "y_pred": pred_values
        }))
    preds_df = pd.concat(preds)
    preds_df.to_csv(output_csv, index=False)
    print(f"Predictions saved to {output_csv}")

# -------------------------------
# Main
# -------------------------------
if __name__ == "__main__":
    X, y, groups, participants, feature_cols, label_cols = load_combined_dataset()
    X_agg, y_agg, participants_agg = aggregate_to_interview_level(X, y, groups)
    train_and_evaluate(X_agg, y_agg, participants_agg, feature_cols, label_cols)
