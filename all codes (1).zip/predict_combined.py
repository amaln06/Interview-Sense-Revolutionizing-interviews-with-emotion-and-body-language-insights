import os
import json
import joblib
import numpy as np
import pandas as pd
from typing import Dict


def load_models(models_dir: str = "models") -> Dict:
    """Load trained regression models and metadata."""
    reg_bundle = joblib.load(os.path.join(models_dir, "reg_models.joblib"))

    with open(os.path.join(models_dir, "metadata.json"), "r", encoding="utf-8") as f:
        metadata = json.load(f)

    reg_models = reg_bundle["models"]
    return reg_models, metadata


def predict_from_aligned_csv(aligned_csv_path: str, models_dir: str = "models") -> Dict:
    """Predict from a single aligned CSV file (frame-level -> interview-level)."""

    # Load models and metadata
    reg_models, metadata = load_models(models_dir)

    # Load and prepare data
    print(f"Loading aligned CSV: {aligned_csv_path}")
    df = pd.read_csv(aligned_csv_path, low_memory=False)

    # Remove unwanted or non-feature columns
    unwanted_cols = [
        "participant_id", "Unnamed: 36", "frame_index", "SMILE_time_sec",
        "participant_question", "SMILE_participant_question",
        "PROS_participant_question", "transcript_text"
    ]
    feature_cols = [col for col in df.columns if col not in unwanted_cols and not col.startswith("LABEL_")]

    # Convert features to numeric and fill NaNs
    X = df[feature_cols].apply(pd.to_numeric, errors="coerce").fillna(0)

    # Aggregate to interview level (same as in training)
    print("Aggregating to interview level...")
    agg_data = {}
    for col in feature_cols:
        agg_data[f"{col}_mean"] = X[col].mean()
        agg_data[f"{col}_std"] = X[col].std()

    # Ensure feature alignment with training metadata
    training_features = metadata["features"]
    X_final = pd.DataFrame([agg_data], columns=training_features).fillna(0)

    # Predict using regression models
    print("Running regression predictions...")
    regression = {}
    regression_rounded = {}

    for label, model in reg_models.items():
        val = float(model.predict(X_final)[0])
        regression[label] = round(val, 3)
        regression_rounded[label] = int(np.clip(np.rint(val), 1, 7))  # rounded 1–7 scale

    # Derive participant ID from filename
    participant_id = os.path.splitext(os.path.basename(aligned_csv_path))[0].replace("_aligned", "")

    # Create final result
    result = {
        "participant_id": participant_id,
        "regression": regression,
        "regression_rounded_1_to_7": regression_rounded
    }

    print(f"Prediction complete for {participant_id}.")
    return result


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage: python predict_combined.py aligned_data_clean/P1_aligned.csv [models_dir]")
        sys.exit(1)

    aligned_csv = sys.argv[1]
    models_dir = sys.argv[2] if len(sys.argv) > 2 else "models"

    result = predict_from_aligned_csv(aligned_csv, models_dir)
    print(json.dumps(result, indent=2))
