import os
import pandas as pd


DROP_COLUMNS = [
	"Unnamed: 36",
	"frame_index",
	"SMILE_time_sec",
	"participant_question",
	"SMILE_participant_question",
	"PROS_participant_question",
	"transcript_text",  # drop unless you explicitly add text features later
]


def clean_one(in_path: str, out_path: str) -> None:
	df = pd.read_csv(in_path)
	cols_to_drop = [c for c in DROP_COLUMNS if c in df.columns]
	if cols_to_drop:
		df = df.drop(columns=cols_to_drop)
	# Optionally drop entirely empty columns
	df = df.dropna(axis=1, how="all")
	os.makedirs(os.path.dirname(out_path), exist_ok=True)
	df.to_csv(out_path, index=False)


def clean_all(aligned_dir: str = "aligned_data", out_dir: str = "aligned_data_clean") -> None:
	if not os.path.isdir(aligned_dir):
		raise NotADirectoryError(aligned_dir)
	files = [f for f in os.listdir(aligned_dir) if f.lower().endswith("_aligned.csv")]
	files.sort()
	if not files:
		print("[WARN] No aligned files found to clean.")
		return
	for fname in files:
		in_path = os.path.join(aligned_dir, fname)
		out_path = os.path.join(out_dir, fname)
		clean_one(in_path, out_path)
		print(f"[CLEANED] {fname} -> {out_path}")


if __name__ == "__main__":
	clean_all()








