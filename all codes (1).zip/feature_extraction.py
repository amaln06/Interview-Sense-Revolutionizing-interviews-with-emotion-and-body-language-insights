import os
import cv2
import mediapipe as mp
import numpy as np
import pandas as pd
from scipy.fftpack import dct

# =====================================================
# FINAL MULTI-VIDEO FACIAL + SMILE FEATURE EXTRACTION
# =====================================================

# ---------- TRUE FEATURE RANGES FROM TRAINING DATA ----------
RANGES = {
    "Pitch": (-3.11858, 3.12414),
    "Yaw": (-1.31509, 1.55243),
    "Roll": (-3.09046, 3.07111),
    "inBrL": (0.618266, 1.60329),
    "otBrL": (0.151442, 2.00561),
    "inBrR": (0.629474, 1.63211),
    "otBrR": (0.0804935, 2.16732),
    "EyeOL": (0.121711, 3.39579),
    "EyeOR": (0.140041, 3.41158),
    "oLipH": (0.233179, 2.58994),
    "iLipH": (0.21847, 6.02435),
    "LipCDt": (0.0823668, 2.73049),
    # Smile
    "SMILE_smile_1": (0.2439, 12.5018),
    "SMILE_smile_2": (-9.18182, 9.18182),
    "SMILE_smile_3": (-1.0, 0.363636),
    "SMILE_smile_4": (-1.0, 0.363636),
}

# DCT coefficient ranges
for i, (mn, mx) in enumerate([
    (-20.6716, 20.6716), (-12.5203, 12.5203), (-8.26481, 8.26481),
    (-6.9085, 6.9085), (-6.46832, 6.46832), (-6.42166, 6.42166),
    (-5.98821, 5.98821), (-5.31028, 5.31028), (-4.9954, 4.9954),
    (-4.5646, 4.5646), (-4.33841, 4.33841), (-4.02294, 4.02294),
    (-3.73196, 3.73196), (-3.63356, 3.63356), (-3.16458, 3.16458),
    (-2.55914, 3.1008), (-2.99886, 2.99886), (-2.82845, 2.82845),
    (-2.71471, 2.71471), (-2.05515, 2.34574), (-2.56068, 2.56068),
    (-2.32044, 2.20734), (-2.30404, 2.30404), (-1.48597, 1.70354),
]):
    RANGES[f"dicCoeff_local{i}"] = (mn, mx)


# ---------- HELPERS ----------
def clamp(value, min_val, max_val):
    return max(min_val, min(max_val, value))


def rescale(value, old_min, old_max, new_min, new_max):
    if old_max == old_min:
        return new_min
    scaled = (value - old_min) / (old_max - old_min)
    return scaled * (new_max - new_min) + new_min


def rescale_and_clamp(value, feature_name, old_min=0, old_max=1):
    if feature_name not in RANGES:
        return value
    new_min, new_max = RANGES[feature_name]
    scaled = rescale(value, old_min, old_max, new_min, new_max)
    return clamp(scaled, new_min, new_max)


# ---------- FACIAL FEATURE EXTRACTION ----------
def extract_facial_features(video_path):
    mp_face_mesh = mp.solutions.face_mesh
    face_mesh = mp_face_mesh.FaceMesh(static_image_mode=False, max_num_faces=1, refine_landmarks=True)
    cap = cv2.VideoCapture(video_path)

    frame_features = []
    frame_num = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            break
        frame_num += 1

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = face_mesh.process(rgb)
        if not results.multi_face_landmarks:
            continue

        landmarks = results.multi_face_landmarks[0]
        h, w, _ = frame.shape
        points = np.array([[lm.x * w, lm.y * h, lm.z * w] for lm in landmarks.landmark])

        # Head pose estimation
        nose, chin = points[1], points[152]
        left_eye, right_eye = points[33], points[263]
        pitch = np.degrees(np.arctan2(chin[1]-nose[1], chin[2]-nose[2]))
        yaw = np.degrees(np.arctan2(right_eye[0]-left_eye[0], right_eye[2]-left_eye[2]))
        roll = np.degrees(np.arctan2(right_eye[1]-left_eye[1], right_eye[0]-left_eye[0]))

        # Eyes and brows
        EyeOL = np.linalg.norm(points[159]-points[145])
        EyeOR = np.linalg.norm(points[386]-points[374])
        inBrL = np.linalg.norm(points[70]-points[107])
        otBrL = np.linalg.norm(points[105]-points[66])
        inBrR = np.linalg.norm(points[336]-points[296])
        otBrR = np.linalg.norm(points[334]-points[293])

        # Lips
        oLipH = np.linalg.norm(points[13]-points[14])
        iLipH = np.linalg.norm(points[17]-points[0])
        LipCDt = np.linalg.norm(points[61]-points[291])

        # DCT
        flat_landmarks = points.flatten()
        dct_values = dct(flat_landmarks, norm="ortho")[:24]

        # Store both raw and scaled
        features_raw = {
            "Pitch_raw": pitch, "Yaw_raw": yaw, "Roll_raw": roll,
            "inBrL_raw": inBrL, "otBrL_raw": otBrL, "inBrR_raw": inBrR, "otBrR_raw": otBrR,
            "EyeOL_raw": EyeOL, "EyeOR_raw": EyeOR, "oLipH_raw": oLipH,
            "iLipH_raw": iLipH, "LipCDt_raw": LipCDt
        }

        features_scaled = {
            "Pitch": rescale_and_clamp(pitch, "Pitch", -180, 180),
            "Yaw": rescale_and_clamp(yaw, "Yaw", -180, 180),
            "Roll": rescale_and_clamp(roll, "Roll", -180, 180),
            "inBrL": rescale_and_clamp(inBrL, "inBrL", 0, 3),
            "otBrL": rescale_and_clamp(otBrL, "otBrL", 0, 3),
            "inBrR": rescale_and_clamp(inBrR, "inBrR", 0, 3),
            "otBrR": rescale_and_clamp(otBrR, "otBrR", 0, 3),
            "EyeOL": rescale_and_clamp(EyeOL, "EyeOL", 0, 5),
            "EyeOR": rescale_and_clamp(EyeOR, "EyeOR", 0, 5),
            "oLipH": rescale_and_clamp(oLipH, "oLipH", 0, 5),
            "iLipH": rescale_and_clamp(iLipH, "iLipH", 0, 8),
            "LipCDt": rescale_and_clamp(LipCDt, "LipCDt", 0, 5),
        }

        dct_scaled = [rescale_and_clamp(val, f"dicCoeff_local{i}", -50, 50) for i, val in enumerate(dct_values)]
        frame_data = [frame_num] + list(features_raw.values()) + list(features_scaled.values()) + dct_scaled
        frame_features.append(frame_data)

    cap.release()
    face_mesh.close()

    cols = (["Frame"] +
            [f"{f}_raw" for f in ["Pitch", "Yaw", "Roll", "inBrL", "otBrL", "inBrR", "otBrR",
                                  "EyeOL", "EyeOR", "oLipH", "iLipH", "LipCDt"]] +
            ["Pitch", "Yaw", "Roll", "inBrL", "otBrL", "inBrR", "otBrR",
             "EyeOL", "EyeOR", "oLipH", "iLipH", "LipCDt"] +
            [f"dicCoeff_local{i}" for i in range(24)])

    return pd.DataFrame(frame_features, columns=cols)


# ---------- SMILE FEATURE EXTRACTION ----------
def extract_smile_features(video_path):
    mp_face_mesh = mp.solutions.face_mesh
    face_mesh = mp_face_mesh.FaceMesh(static_image_mode=False, max_num_faces=1)
    cap = cv2.VideoCapture(video_path)

    frame_features = []

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = face_mesh.process(frame_rgb)

        if results.multi_face_landmarks:
            lm = results.multi_face_landmarks[0].landmark
            def p(lm): return np.array([lm.x, lm.y])

            left_corner, right_corner = p(lm[61]), p(lm[291])
            top_lip, bottom_lip = p(lm[13]), p(lm[14])
            nose_tip = p(lm[1])
            left_eye, right_eye = p(lm[33]), p(lm[263])

            mouth_width = np.linalg.norm(left_corner - right_corner)
            face_width = np.linalg.norm(left_eye - right_eye)
            corner_lift = (nose_tip[1] - ((left_corner[1] + right_corner[1]) / 2))

            smile_1 = ((mouth_width / face_width) * 2.0) - (corner_lift * 5.0)
            smile_3 = (left_corner[1] - right_corner[1])
            frame_features.append([smile_1, smile_3])

    cap.release()
    face_mesh.close()

    if len(frame_features) < 2:
        return pd.DataFrame(columns=["SMILE_smile_1", "SMILE_smile_2", "SMILE_smile_3", "SMILE_smile_4"])

    frame_features = np.array(frame_features)
    smile_1_series, smile_3_series = frame_features[:, 0], frame_features[:, 1]
    smile_2 = np.diff(smile_1_series, prepend=smile_1_series[0])
    smile_4 = 0.3 - np.abs(smile_2) * 0.05

    df_smile = pd.DataFrame({
        "SMILE_smile_1": [rescale_and_clamp(v, "SMILE_smile_1", 0, 15) for v in smile_1_series],
        "SMILE_smile_2": [rescale_and_clamp(v, "SMILE_smile_2", -10, 10) for v in smile_2],
        "SMILE_smile_3": [rescale_and_clamp(v, "SMILE_smile_3", -1.5, 0.5) for v in smile_3_series],
        "SMILE_smile_4": [rescale_and_clamp(v, "SMILE_smile_4", -1.5, 0.5) for v in smile_4],
    })
    return df_smile


# ---------- MAIN PIPELINE ----------
def extract_combined_features(video_path):
    video_name = os.path.splitext(os.path.basename(video_path))[0]
    output_dir = f"{video_name}_extracted_features"
    os.makedirs(output_dir, exist_ok=True)

    print(f"🎥 Extracting features from: {video_name}")

    df_facial = extract_facial_features(video_path)
    df_smile = extract_smile_features(video_path)

    min_len = min(len(df_facial), len(df_smile))
    df_facial, df_smile = df_facial.iloc[:min_len], df_smile.iloc[:min_len]

    combined_df = pd.concat([df_facial.reset_index(drop=True),
                             df_smile.reset_index(drop=True)], axis=1)

    frame_csv = os.path.join(output_dir, "combined_frame_level.csv")
    combined_df.to_csv(frame_csv, index=False)
    print(f"✅ Frame-level CSV saved: {frame_csv} ({len(combined_df)} frames)")

    # 🔹 Drop raw columns for aggregation
    df_scaled_only = combined_df.loc[:, ~combined_df.columns.str.contains("_raw")]

    agg_features = {}
    for col in df_scaled_only.columns[1:]:
        agg_features[f"{col}_mean"] = df_scaled_only[col].mean()
        agg_features[f"{col}_std"] = df_scaled_only[col].std()

    agg_df = pd.DataFrame([agg_features])
    agg_csv = os.path.join(output_dir, "aggregated_features.csv")
    agg_df.to_csv(agg_csv, index=False)
    print(f"✅ Aggregated CSV saved: {agg_csv}")

    return combined_df, agg_df


# ---------- MULTI-VIDEO SUPPORT ----------
if __name__ == "__main__":
    videos = ["P1.mp4"]  # 🔹 Add your video filenames here
    for v in videos:
        if os.path.exists(v):
            extract_combined_features(v)
        else:
            print(f"⚠️ Skipping {v} (file not found)")
