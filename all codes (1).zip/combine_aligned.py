import os
import pandas as pd
from typing import List


def combine_aligned_files(input_dir: str = "aligned_data_clean", output_file: str = "combined_aligned_dataset.csv") -> None:
    """Combine all cleaned aligned CSV files into one master dataset."""
    
    if not os.path.isdir(input_dir):
        raise NotADirectoryError(f"Input directory not found: {input_dir}")
    
    # Get all aligned CSV files
    files = [f for f in os.listdir(input_dir) if f.lower().endswith("_aligned.csv")]
    files.sort()
    
    if not files:
        print("[WARN] No aligned files found to combine.")
        return
    
    print(f"Found {len(files)} aligned files to combine...")
    
    # Read and combine all files
    combined_data = []
    participant_ids = []
    
    for fname in files:
        # Extract participant ID from filename
        participant_id = fname.replace("_aligned.csv", "")
        participant_ids.append(participant_id)
        
        # Read the file
        file_path = os.path.join(input_dir, fname)
        df = pd.read_csv(file_path)
        
        # Add participant_id column
        df['participant_id'] = participant_id
        
        # Add to combined data
        combined_data.append(df)
        print(f"Added {fname} ({len(df)} rows)")
    
    # Combine all dataframes
    master_df = pd.concat(combined_data, ignore_index=True)
    
    # Save combined dataset
    master_df.to_csv(output_file, index=False)
    
    print(f"\n[SUCCESS] Combined dataset saved to: {output_file}")
    print(f"Total participants: {len(participant_ids)}")
    print(f"Total rows: {len(master_df)}")
    print(f"Total columns: {len(master_df.columns)}")
    print(f"Participant IDs: {participant_ids}")


if __name__ == "__main__":
    combine_aligned_files()






