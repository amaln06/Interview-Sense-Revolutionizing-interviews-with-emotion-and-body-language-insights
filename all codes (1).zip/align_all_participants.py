import os
import sys
import pandas as pd
import numpy as np

def safe_read_csv(path, **kwargs):
    """Read with fallback encodings and return DataFrame (empty on failure)."""
    if not os.path.exists(path):
        print(f"[WARN] file not found: {path}")
        return pd.DataFrame()
    try:
        return pd.read_csv(path, **kwargs)
    except UnicodeDecodeError:
        try:
            return pd.read_csv(path, encoding="latin1", **kwargs)
        except Exception as e:
            print(f"[ERROR] reading {path}: {e}")
            return pd.DataFrame()
    except Exception as e:
        print(f"[ERROR] reading {path}: {e}")
        return pd.DataFrame()

def load_smile(smile_path):
    if not os.path.exists(smile_path):
        print(f"[WARN] smile file not found: {smile_path}")
        return pd.DataFrame()
    try:
        s = pd.read_csv(smile_path, sep=r"\s+", header=None, engine="python")
    except Exception:
        s = safe_read_csv(smile_path, sep=r"\s+", header=None, engine="python")
    if s.shape[1] == 1:
        s.columns = ["time_sec"]
    else:
        cols = ["time_sec"] + [f"smile_{i}" for i in range(1, s.shape[1])]
        s.columns = cols
    s["time_sec"] = pd.to_numeric(s["time_sec"], errors="coerce")
    s = s.dropna(subset=["time_sec"]).reset_index(drop=True)
    return s

def load_transcripts(path, pid):
    if not os.path.exists(path):
        print(f"[WARN] transcripts file not found: {path}")
        return ""
    try:
        t = pd.read_csv(path, sep="\t", header=None, encoding="latin1", engine="python")
        mask = t[0].astype(str).str.lower() == pid.lower()
        if mask.any():
            text = t[mask].iloc[0, 1]
            return str(text)
        else:
            for _, r in t.iterrows():
                row0 = str(r.iloc[0])
                if row0.strip().lower().startswith(pid.lower()):
                    if len(r) > 1:
                        return str(r.iloc[1])
                    else:
                        return row0
            return ""
    except Exception:
        with open(path, "r", encoding="latin1", errors="ignore") as f:
            for line in f:
                parts = line.strip().split("\t", 1)
                if len(parts) >= 2 and parts[0].strip().lower() == pid.lower():
                    return parts[1].strip()
        return ""

def align_for_participant(pid):
    print(f"\n[INFO] Aligning participant: {pid}")

    base = "dataset"
    facial_path = os.path.join(base, "facial_features", "pre", f"{pid}.csv")
    smile_path = os.path.join(base, "smiledata", "pre", f"Smoothed-features-{pid}.txt")
    prosody_path = os.path.join(base, "prosody", "prosodic_features.csv")
    transcripts_path = os.path.join(base, "labels", "interview_transcripts_by_turkers.csv")
    turker_path = os.path.join(base, "labels", "turker_scores_full_interview.csv")
    out_dir = "aligned_data"
    os.makedirs(out_dir, exist_ok=True)

    # load
    print("[*] Loading facial features...")
    facial = safe_read_csv(facial_path)
    if facial.empty:
        print(f"[ERROR] Could not load facial features for {pid}. Aborting.")
        return

    print("[*] Loading smile data...")
    smile = load_smile(smile_path)

    print("[*] Loading prosody file...")
    prosody = safe_read_csv(prosody_path)
    if not prosody.empty and "participant_question" not in prosody.columns:
        first_col = prosody.columns[0]
        prosody = prosody.rename(columns={first_col: "participant_question"})
    prosody = prosody.loc[:, ~prosody.columns.str.contains("^Unnamed")]

    # filter prosody for this participant
    prosody_p = pd.DataFrame()
    if not prosody.empty:
        prosody_p = prosody[prosody["participant_question"].astype(str).str.upper().str.startswith(pid.upper())].copy()
        prosody_p.reset_index(drop=True, inplace=True)
    print(f"    prosody rows found for {pid}: {len(prosody_p)}")

    # transcripts
    transcript_text = load_transcripts(transcripts_path, pid)
    if transcript_text:
        print("    transcript loaded (full interview).")
    else:
        print("    no transcript text found for this participant (okay).")

    # turker scores (AGGR)
    turker = safe_read_csv(turker_path)
    aggr_row = pd.DataFrame()
    if not turker.empty:
        part_col = None
        for c in turker.columns:
            if c.strip().lower() == "participant":
                part_col = c
                break
        worker_col = None
        for c in turker.columns:
            if c.strip().lower() == "worker":
                worker_col = c
                break
        if part_col and worker_col:
            mask = turker[part_col].astype(str).str.lower() == pid.lower()
            aggr_candidates = turker[mask]
            aggr_row = aggr_candidates[aggr_candidates[worker_col].astype(str).str.upper() == "AGGR"]
            if aggr_row.empty and not aggr_candidates.empty:
                aggr_row = aggr_candidates.tail(1)
        else:
            print("[WARN] could not find Participant/Worker columns in turker file.")
    print(f"    AGGR row found: {len(aggr_row) > 0}")

    # ---- determine question time windows using prosody durations ----
    question_windows = []
    if not prosody_p.empty and "duration" in prosody_p.columns:
        durations = pd.to_numeric(prosody_p["duration"], errors="coerce").fillna(0).astype(float)
        starts = durations.cumsum().shift(fill_value=0.0)
        ends = starts + durations
        for i, q in prosody_p.iterrows():
            question_windows.append({
                "participant_question": q["participant_question"],
                "start": starts.iloc[i],
                "end": ends.iloc[i],
                "prosody_idx": i
            })
        print(f"    built {len(question_windows)} question windows from prosody durations")
    else:
        print("    WARNING: prosody durations not available; questions will be assigned by order instead")

    # ---- map smile rows to questions by time ----
    smile_question = pd.Series([None]*len(smile), index=smile.index)
    if not smile.empty and question_windows:
        for i, srow in smile.iterrows():
            t = srow["time_sec"]
            assigned = None
            for qw in question_windows:
                if t >= qw["start"] and t < qw["end"]:
                    assigned = qw["participant_question"]
                    break
            if assigned is None:
                starts = np.array([ (qw["start"] - t) for qw in question_windows ] )
                idx = int(np.abs(starts).argmin())
                assigned = question_windows[idx]["participant_question"]
            smile_question.iloc[i] = assigned
        smile = smile.copy()
        smile["participant_question"] = smile_question.values
        print("    assigned questions to smile rows based on prosody windows")
    else:
        if not smile.empty:
            smile["participant_question"] = None

    # ---- Map facial frames to smile rows (nearest index mapping) ----
    facial = facial.reset_index(drop=True)
    facial["frame_index"] = facial.index
    mapped_smile_idx = []
    if not smile.empty:
        n_f = len(facial)
        n_s = len(smile)
        if n_s == 0:
            mapped_smile_idx = [None]*n_f
        else:
            for i in range(n_f):
                s_i = int(round(i * (n_s - 1) / max(1, n_f - 1)))
                mapped_smile_idx.append(s_i)
    else:
        mapped_smile_idx = [None]*len(facial)

    # Build final rows
    rows = []
    for f_idx, f_row in facial.iterrows():
        row = f_row.to_dict()
        sidx = mapped_smile_idx[f_idx] if f_idx < len(mapped_smile_idx) else None
        if sidx is not None and sidx < len(smile):
            srow = smile.iloc[sidx]
            for c in smile.columns:
                row[f"SMILE_{c}"] = srow[c]
            row["participant_question"] = srow.get("participant_question", None)
        else:
            for c in (smile.columns if not smile.empty else []):
                row[f"SMILE_{c}"] = None
            row["participant_question"] = None

        pq = row.get("participant_question", None)
        pros_row = None
        if pq is not None and not prosody_p.empty:
            mask = prosody_p["participant_question"].astype(str).str.upper() == str(pq).upper()
            if mask.any():
                pros_row = prosody_p[mask].iloc[0]
        if pros_row is None and not prosody_p.empty:
            pros_row = prosody_p.iloc[0]
        if pros_row is not None:
            for c in prosody_p.columns:
                row[f"PROS_{c}"] = pros_row[c]
        else:
            for c in prosody.columns if not prosody.empty else []:
                row[f"PROS_{c}"] = None

        row["transcript_text"] = transcript_text

        score_cols = [
            "Overall", "RecommendHiring", "Colleague", "Engaged", "Excited", "EyeContact",
            "Smiled", "SpeakingRate", "NoFillers", "Friendly", "Paused", "EngagingTone",
            "StructuredAnswers", "Calm", "NotStressed", "Focused", "Authentic", "NotAwkward", "Total"
        ]
        if not aggr_row.empty:
            for sc in score_cols:
                if sc in aggr_row.columns:
                    try:
                        val = float(aggr_row.iloc[0][sc])
                    except Exception:
                        val = aggr_row.iloc[0][sc]
                    row[f"LABEL_{sc}"] = val
                else:
                    row[f"LABEL_{sc}"] = None
        else:
            for sc in score_cols:
                row[f"LABEL_{sc}"] = None

        rows.append(row)

    out_df = pd.DataFrame(rows)
    out_path = os.path.join(out_dir, f"{pid}_aligned.csv")
    out_df.to_csv(out_path, index=False)
    print(f"[DONE] Saved aligned file: {out_path}  (rows: {len(out_df)})")

if __name__ == "__main__":
    # List of participant IDs to process (P3 to P6)
    participants = ["P3", "P4", "P5", "P6"]
    
    for pid in participants:
        align_for_participant(pid)
